//
//  shopTableViewCell.swift
//  jackolantern
//
//  Created by Eric Pfister on 8/20/16.
//  Copyright © 2016 com.etrickery. All rights reserved.
//

import UIKit

class shopTableViewCell: UITableViewCell {

    //shopname
    @IBOutlet weak var shopName: UILabel!
    
    //shop phone number
    @IBOutlet weak var shopNumber: UILabel!
    
}
