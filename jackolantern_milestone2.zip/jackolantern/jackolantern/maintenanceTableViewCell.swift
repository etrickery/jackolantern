//
//  maintenanceTableViewCell.swift
//  jackolantern
//
//  Created by Eric Pfister on 8/20/16.
//  Copyright © 2016 com.etrickery. All rights reserved.
//

import UIKit

class maintenanceTableViewCell: UITableViewCell {
    
    
    //interval
    @IBOutlet weak var intervalLabel: UILabel!
    
    //i like to call it itemaction
    @IBOutlet weak var itemActionLabel: UILabel!
    
    
    

}
