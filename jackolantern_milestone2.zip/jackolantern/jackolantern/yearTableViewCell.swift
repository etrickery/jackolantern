//
//  yearTableViewCell.swift
//  jackolantern
//
//  Created by Eric Pfister on 8/15/16.
//  Copyright © 2016 com.etrickery. All rights reserved.
//

import UIKit

class yearTableViewCell: UITableViewCell {

    
    //year cell stuff
    @IBOutlet weak var yearLabel: UILabel!


}
