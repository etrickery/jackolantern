//
//  commonTableData.swift
//  jackolantern
//
//  Created by Eric Pfister on 8/9/16.
//  Copyright © 2016 com.etrickery. All rights reserved.
//


import UIKit


class commonTableData {
    
    
    var title : String
    var details : String
    var image : String
    
    
    
    
    init(title : String, details : String, image : String){
        self.title = title
        self.details = details
        self.image = image
        
    }
    
    
    
}